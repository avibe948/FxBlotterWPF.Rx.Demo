﻿using System;
using System.Collections.Generic;

namespace PriceSupplier
{
    public static class SourceFactory
    {
        private static Dictionary<string, decimal> AvailableCurrencyPairs;
        
        static SourceFactory()
        {
            AvailableCurrencyPairs = new Dictionary<string, decimal>
            {
                {"AUDUSD", 0.66m},
                {"EURUSD", 1.07m},
                {"GBPUSD", 1.21m},
                {"USDCAD", 1.38m},
                {"USDCHF", 0.91m},
                {"USDJPY", 133m},
                {"USDNOK", 10.6m},
                {"USDNZD", 0.62m},
                {"USDSEK", 10.71m}
            };
        }

        public static PriceSource GetSource(string currencyPair)
        {
            if (!AvailableCurrencyPairs.TryGetValue(currencyPair, out var px))
            {
                throw new NotImplementedException();
            }

            return new PriceSource(currencyPair, px);
        }
    }
}
