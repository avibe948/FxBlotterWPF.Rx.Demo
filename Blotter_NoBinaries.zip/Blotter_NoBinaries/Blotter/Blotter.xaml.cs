﻿using System.Windows;

namespace Blotter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            ConsoleWrapper.ShowConsoleWindow();

            InitializeComponent();

            Grid.ItemsSource = new BlotterRow[]
            {
                new BlotterRow("EURUSD"),
                new BlotterRow("GBPUSD"),
                new BlotterRow("USDJPY"),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
                new BlotterRow(null),
            };
        }
    }
}
