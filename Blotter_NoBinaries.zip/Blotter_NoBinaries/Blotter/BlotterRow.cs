﻿using System;
using System.ComponentModel;
using System.Reactive.Linq;
using System.Windows;
using PriceSupplier;

namespace Blotter
{
    public class BlotterRow : INotifyPropertyChanged
    {
        private PriceSource _priceSource;

        public BlotterRow(string ccypair)
        {
            CurrencyPair = ccypair;
        }

        public string CurrencyPair
        {
            get => _priceSource.CurrencyPair;
            set
            {
                if (value != null)
                {
                    try
                    {
                        _priceSource = SourceFactory.GetSource(value);
                    }
                    catch
                    {
                        Application.Current.Shutdown();
                    }
                }
            }
        }

        public decimal Price
        {
            get => _priceSource.Price;
            set => _priceSource.Price = value;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void PriceChanged()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Price"));
        }
    }
}
